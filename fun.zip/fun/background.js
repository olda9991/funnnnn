try { chrome.runtime.onInstalled.addListener(() => {}); } catch(e) {}
